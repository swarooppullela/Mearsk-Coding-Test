var grid = $('#grid');
var numbers = [];
var number = 1;
var rowid = 1;
var x = window.matchMedia("(min-width: 960px)");
var y = window.matchMedia("(min-width:1024px)");
while (number <= 9) {
    var row = document.createElement("div");
    row.className = "number-row";
    row.id = rowid;
    for (var j = 1; j <= 3; j++) {
        var innerdiv = document.createElement("div");
        innerdiv.className = "number-align";
        innerdiv.innerText = number;
        var col = document.createElement("div");
        col.className = "column";
        if (x.matches || y.matches) {
            col.style.backgroundColor = (number == 1 || number == 8) ? "#6F98A8" : (number == 2 || number == 4) ? "#2B8EAD" : (number == 3 || number == 5 || number == 9) ? "#2F454E" : (number == 6 || number == 7) ? "#BFBFBF" : "";
        }
        else {
            innerdiv.style.borderLeft = (number == 1 || number == 8) ? "0.5em solid #6F98A8" : (number == 2 || number == 4) ? "0.5em solid #2B8EAD" : (number == 3 || number == 5 || number == 9) ? "0.5em solid #2F454E" : (number == 6 || number == 7) ? "0.5em solid #BFBFBF" : "";
        }
            col.appendChild(innerdiv);
        row.appendChild(col);
        numbers.push(number);
        number++;
    }
    grid.append(row);
    rowid++;
}

$("#shuffle").click(function () {
    var Swap, temp;
    for (var i = numbers.length - 1; i > 0; i--) {
        Swap = Math.floor(Math.random() * (i + 1));
        temp = numbers[i];
        numbers[i] = numbers[Swap];
        numbers[Swap] = temp;
    }
    i = 0;
    $('.number-align').each(function () {
        this.innerHTML = numbers[i];
        i++;
    });
});

$("#sort").click(function () {
    numbers.sort();
    i = 0;
    $('.number-align').each(function () {
        this.innerHTML = numbers[i];
        i++;
    });
});